<!DOCTYPE html>
<html lang="ca"> 
<head>
		<meta charset="UTF-8">
		<title>Document</title>
		<link rel="stylesheet" href="css/reset.css">
		<link rel="stylesheet" href="css/960_12_col.css">
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />

</head>
<body>
	
		<div id="barra" class="container_12">

			<ul class="grid_5 push_7" >

				<a href="<?php bloginfo('template_directory'); ?>/mostres/quiensoy.jpg"><li>Quien Soy</li></a>
				<a href="<?php bloginfo('template_directory'); ?>/mostres/cv-3.jpg"><li>Mi CV</li></a>
				<a href="mailto:aherrador.crn@artsgrafiques.org"><li>Contacto</li></a>
			</ul>
		
		</div>
