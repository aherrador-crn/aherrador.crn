
<?php get_header(); ?>

		<div id="cos" class=""></div>

		

		<div id="galeria" class="container_12">
			
			<div class="tema grid_4">
				<a href="<?php bloginfo('template_directory'); ?>/mostres/disenoo.pdf">      
					<img src="<?php bloginfo('template_directory'); ?>/img/diseno.png">
				</a>	
			</div>

			<div class="tema grid_4">
				<a href="<?php bloginfo('template_directory'); ?>/mostres/maquetacionn.pdf">
					<img src="<?php bloginfo('template_directory'); ?>/img/maqueta.png">
				</a>	
			</div>

			<div class="tema grid_4">
			<a href="<?php bloginfo('template_directory'); ?>/mostres/recordatorioss.pdf">				
				<img src="<?php bloginfo('template_directory'); ?>/img/recorda.png">
			</a>
			</div>
			

			<div class="tema grid_4">
				<img src="<?php bloginfo('template_directory'); ?>/img/960_grid_12_col_03...png" height="193px" width="300">	
			</div>

			<div class="tema grid_4">
				<img src="<?php bloginfo('template_directory'); ?>/img/960_grid_12_col_05...png" height="193px" width="300">
			</div>

			<div class="tema grid_4">
				<img src="<?php bloginfo('template_directory'); ?>/img/960_grid_12_col_07...png" height="193px" width="300">
			</div>

			<div class="tema grid_4">
				<img src="<?php bloginfo('template_directory'); ?>/img/960_grid_12_col_11...png" height="193px" width="300">
			</div>

			<div class="tema grid_4">
				<img src="<?php bloginfo('template_directory'); ?>/img/960_grid_12_col_12...png" height="193px" width="300">
			</div>

			<div class="tema grid_4">
				<img src="<?php bloginfo('template_directory'); ?>/img/960_grid_12_col_13...png" height="193px" width="300">
			</div>
			
			<div class="tema grid_4">
				<img src="<?php bloginfo('template_directory'); ?>/img/PARIS_08.png" height="193px" width="300">
			</div>

			<div class="tema grid_4">
				<img src="<?php bloginfo('template_directory'); ?>/img/960_grid_12_col_17...png" height="193px" width="300">
			</div>



			<div class="tema grid_4"> 
				<a href="<?php bloginfo('template_directory'); ?>/mostres/redes.jpg">
					<img src="<?php bloginfo('template_directory'); ?>/img/960_grid_12_col_20.png" height="193px" width="300">
				
			</div>
			


</body>
</html>


				
</div>
	

<?php get_footer(); ?>		
